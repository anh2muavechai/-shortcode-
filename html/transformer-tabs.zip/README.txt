A Pen created at CodePen.io. You can find this one at http://codepen.io/chriscoyier/pen/gHnGD.

 RWD n stuff!

One set of semantic HTML. One set of JS.

Tabs that turn into a small-screen-capable tap-to-reveal fully-functional system. 

I used to use `&lt;select>` sometimes for this but that's different markup and different JS and that sucks. Plus this is easier (funner) to style.