A Pen created at CodePen.io. You can find this one at https://codepen.io/_massimo/pen/JXELvz.

 simple pacman loader